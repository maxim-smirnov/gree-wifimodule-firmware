#!/bin/sh
ifconfig wlan0 down

echo "rm  /mnt/wpa_supplicant.conf"
rm -rf /mnt/wpa_supplicant.conf
 
sync

echo "Restart Demo Normal."

killall factory_demo

sleep 2

./demo 1 &

sh /home/autoRun.sh &
sh /home/date_sync.sh &

